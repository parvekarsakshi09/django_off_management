from django.contrib import admin
from .models import Employee, Role, Department
# Register your models here.
from import_export.admin import ImportExportModelAdmin;
from . import models
class departmentadmin(ImportExportModelAdmin,admin.ModelAdmin):
    ...
admin.site.register(models.Department,departmentadmin)

class employeeadminadmin(ImportExportModelAdmin,admin.ModelAdmin):
    ...

admin.site.register(models.Employee,employeeadminadmin)

class roleadmin(ImportExportModelAdmin,admin.ModelAdmin):
    ...


admin.site.register(models.Role,roleadmin)
