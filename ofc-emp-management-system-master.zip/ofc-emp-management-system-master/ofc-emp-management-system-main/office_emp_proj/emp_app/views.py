# import profile
# from django.shortcuts import render, HttpResponse
# from .models import Employee, Role, Department
# from datetime import datetime
# from django.db.models import Q


# # # Create your views here.
# # def index(request):
# #     # lables=[]
# #     # data=[]
# #     # queryset=profile.objects.order_by('-age')[:5]
# #     # for person in queryset:
# #     #     labels.append(person.)
# #     return render(request, 'index.html')



# # def all_emp(request):
# #     emps = Employee.objects.all()
# #     context = {
# #         'emps': emps
# #     }
# #     print(context)
# #     return render(request, 'view_all_emp.html', context)


# # def add_emp(request):
# #     if request.method == 'POST':
# #         first_name = request.POST['first_name']
# #         last_name = request.POST['last_name']
# #         salary = int(request.POST['salary'])
# #         bonus = int(request.POST['bonus'])
# #         phone = int(request.POST['phone'])
# #         dept = int(request.POST['dept'])
# #         role = int(request.POST['role'])
# #         new_emp = Employee(first_name= first_name, last_name=last_name, salary=salary, bonus=bonus, phone=phone, dept_id = dept, role_id = role, hire_date = datetime.now())
# #         new_emp.save()
# #         return HttpResponse('Employee added Successfully')
# #     elif request.method=='GET':
# #         return render(request, 'add_emp.html')
# #     else:
# #         return HttpResponse("An Exception Occured! Employee Has Not Been Added")


# # def remove_emp(request, emp_id = 0):
# #     if emp_id:
# #         try:
# #             emp_to_be_removed = Employee.objects.get(id=emp_id)
# #             emp_to_be_removed.delete()
# #             return HttpResponse("Employee Removed Successfully")
# #         except:
# #             return HttpResponse("Please Enter A Valid EMP ID")
# #     emps = Employee.objects.all()
# #     context = {
# #         'emps': emps
# #     }
# #     return render(request, 'remove_emp.html',context)


# # def filter_emp(request):
# #     if request.method == 'POST':
# #         name = request.POST['name']
# #         dept = request.POST['dept']
# #         role = request.POST['role']
# #         emps = Employee.objects.all()
# #         if name:
# #             emps = emps.filter(Q(first_name__icontains = name) | Q(last_name__icontains = name))
# #         if dept:
# #             emps = emps.filter(dept__name__icontains = dept)
# #         if role:
# #             emps = emps.filter(role__name__icontains = role)

# #         context = {
# #             'emps': emps
# #         }
# #         return render(request, 'view_all_emp.html', context)

# #     elif request.method == 'GET':
# #         return render(request, 'filter_emp.html')
# #     else:
# #         return HttpResponse('An Exception Occurred')






# # add_emp view
# def add_emp(request):
#     if request.method == 'POST':
#         try:
#             first_name = request.POST['first_name']
#             last_name = request.POST['last_name']
#             salary = int(request.POST['salary'])
#             bonus = int(request.POST['bonus'])
#             phone = int(request.POST['phone'])
#             dept = int(request.POST['dept'])
#             role = int(request.POST['role'])
#             new_emp = Employee(first_name=first_name, last_name=last_name, salary=salary, bonus=bonus, phone=phone,
#                                dept_id=dept, role_id=role, hire_date=datetime.now())
#             new_emp.save()
#             return HttpResponse('Employee added Successfully')
#         except ValueError:
#             return HttpResponse("Invalid input data. Please ensure salary, bonus, phone, dept, and role are integers.")
#     elif request.method == 'GET':
#         return render(request, 'add_emp.html')
#     else:
#         return HttpResponse("An Exception Occurred! Employee Has Not Been Added")


# # remove_emp view
# def remove_emp(request, emp_id=0):
#     if emp_id:
#         try:
#             emp_to_be_removed = Employee.objects.get(id=emp_id)
#             emp_to_be_removed.delete()
#             return HttpResponse("Employee Removed Successfully")
#         except Employee.DoesNotExist:
#             return HttpResponse("Employee with the provided ID does not exist.")
#         except Exception as e:
#             return HttpResponse("An error occurred: " + str(e))
#     emps = Employee.objects.all()
#     context = {
#         'emps': emps
#     }
#     return render(request, 'remove_emp.html', context)


from django.shortcuts import render, HttpResponse
from .models import Employee, Role, Department
from datetime import datetime
from django.db.models import Q

def index(request):
    # Your index view code here
    return render(request, 'index.html')

def all_emp(request):
    emps = Employee.objects.all()
    context = {
        'emps': emps
    }
    return render(request, 'view_all_emp.html', context)

def add_emp(request):
    if request.method == 'POST':
        # Get data from the form
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        salary = int(request.POST['salary'])
        bonus = int(request.POST['bonus'])
        phone = int(request.POST['phone'])
        dept = int(request.POST['dept'])
        role = int(request.POST['role'])
        # Create a new employee object and save it
        new_emp = Employee.objects.create(
            first_name=first_name,
            last_name=last_name,
            salary=salary,
            bonus=bonus,
            phone=phone,
            dept_id=dept,
            role_id=role,
            hire_date=datetime.now()
        )
        return HttpResponse('Employee added Successfully')
    elif request.method == 'GET':
        # Render the add employee form
        return render(request, 'add_emp.html')
    else:
        return HttpResponse('An Exception Occurred! Employee Has Not Been Added')

def remove_emp(request, emp_id=0):
    if emp_id:
        try:
            # Get the employee object by ID and delete it
            emp_to_be_removed = Employee.objects.get(id=emp_id)
            emp_to_be_removed.delete()
            return HttpResponse('Employee Removed Successfully')
        except:
            return HttpResponse('Please Enter A Valid EMP ID')
    else:
        # Render a page to select employee for removal
        emps = Employee.objects.all()
        context = {
            'emps': emps
        }
        return render(request, 'remove_emp.html', context)

def filter_emp(request):
    if request.method == 'POST':
        # Get filter parameters from the form
        name = request.POST['name']
        dept = request.POST['dept']
        role = request.POST['role']
        # Filter employees based on parameters
        emps = Employee.objects.all()
        if name:
            emps = emps.filter(Q(first_name__icontains=name) | Q(last_name__icontains=name))
        if dept:
            emps = emps.filter(dept__name__icontains=dept)
        if role:
            emps = emps.filter(role__name__icontains=role)
        context = {
            'emps': emps
        }
        return render(request, 'view_all_emp.html', context)
    elif request.method == 'GET':
        # Render the filter employee form
        return render(request, 'filter_emp.html')
    else:
        return HttpResponse('An Exception Occurred')
